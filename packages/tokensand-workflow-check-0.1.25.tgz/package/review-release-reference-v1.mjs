#!/usr/bin/env node
// Preview a local, developer-reported release comparison. Execute only in the trusted candidate service.
import { createHash, createHmac } from "node:crypto";
import { execFileSync, fork } from "node:child_process";
import { constants } from "node:fs";
import { mkdir, mkdtemp, open, readFile, realpath, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, isAbsolute, join, relative, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { parseArgs } from "node:util";

const help = `Keep review-release-reference-v1.mjs and review-repair-v1.mjs together. From your clean candidate service checkout, run
  node /path/to/review-release-reference-v1.mjs REFERENCE_RUN CANDIDATE_RUN --reference TAG_OR_SHA --case CASE_ID [--include-tool NAME ...]

Use the private Node SDK 0.7.7 already installed in the service. For a fresh checkout, get the team's pinned SDK from Build & Evaluate → Connect app, then install your lockfile dependencies. No Tokens& key is needed for local review.
The preview identifies your chosen Git revision. Confirm deployment provenance separately.
The default note includes the case, revisions and scores. Add --include-tool once per name to include its recorded timing and outcomes.
The local worker scores both sets of saved outputs with the reference sources and SDK 0.7.7. External scorer dependencies outside the declared files can yield an unknown result.
Exit 0 means the selected case still passes. Exit 100 means it regressed. Exit 2 means the evidence is inconclusive.`;
const workerPath = fileURLToPath(new URL("./review-repair-v1.mjs", import.meta.url));
const sha = data => createHash("sha256").update(data).digest("hex");
const hash = /^[a-f0-9]{64}$/;
const caseId = /^[a-zA-Z0-9_-]{1,80}$/;
const toolName = /^[a-z][a-z0-9_-]{0,39}$/;
class Unknown extends Error {}
function requireEvidence(condition, reason) {
  if (!condition) throw new Unknown(reason);
}
const env = { PATH: process.env.PATH, SystemRoot: process.env.SystemRoot, GIT_ALLOW_PROTOCOL: "", GIT_NO_LAZY_FETCH: "1" };
function git(...args) {
  return execFileSync("git", ["--no-replace-objects", ...args], { env, stdio: ["ignore", "pipe", "ignore"], timeout: 5000, maxBuffer: 8 * 1024 * 1024 });
}

async function readJson(path, budget) {
  const file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  try {
    const info = await file.stat();
    requireEvidence(info.isFile() && info.size <= 8 * 1024 * 1024 && info.size <= budget.remaining, "The selected evidence exceeds the local review limit.");
    budget.remaining -= info.size;
    return JSON.parse(await file.readFile("utf8"));
  } finally { await file.close(); }
}

function scorerDependencies(frozen, sources) {
  requireEvidence(Array.isArray(frozen.evaluatorSources), "Both runs must declare their scorer dependencies.");
  return frozen.evaluatorSources.map(path => {
    requireEvidence(hash.test(sources.get(path)), "A declared scorer dependency is missing.");
    return [relative(dirname(frozen.config), path), sources.get(path)];
  }).sort(([a], [b]) => a.localeCompare(b));
}

async function readRun(directory, id, budget, {canonical, validateExperimentPlan}) {
  const frozen = await readJson(join(directory, "plan.json"), budget);
  const result = await readJson(join(directory, "result.json"), budget);
  const plan = frozen.plan;
  validateExperimentPlan(plan);
  requireEvidence(result.kind === "local-workflow-comparison" && result.schemaVersion === 1 && frozen.schemaVersion === 1
    && result.id === frozen.id && result.state === "complete" && canonical(result.plan) === canonical(plan)
    && plan.maxCallsPerRun.baseline === 0 && plan.maxCallsPerRun.candidate === 0 && plan.sourceGitCommit
    && typeof frozen.privateInputKey === "string" && hash.test(frozen.privateInputKey), "Use complete, revision-bound, zero-provider local SDK runs.");
  const selected = plan.cases.find(row => row.id === id);
  requireEvidence(selected, "Both runs must include the selected case.");
  const sources = new Map(frozen.sources.map(row => [row.path, row.sha256]));
  requireEvidence(sources.size === frozen.sources.length && hash.test(sources.get(frozen.config))
    && hash.test(frozen.functionDigests?.evaluator), "The saved workflow or scorer identity is incomplete.");
  const dependencies = scorerDependencies(frozen, sources);
  const checks = plan.checks.map(check => check.id);
  const seen = new Set();
  const rows = [];
  const outputs = { baseline: [], candidate: [] };
  for (const [index, row] of result.runs.entries()) {
    const key = [row.caseId, row.variant, row.repetition].join("/");
    requireEvidence(plan.cases.some(c => c.id === row.caseId) && ["baseline", "candidate"].includes(row.variant)
      && Number.isInteger(row.repetition) && row.repetition >= 0 && row.repetition < plan.repetitions && !seen.has(key), "The recorded trials are invalid or duplicated.");
    seen.add(key);
    if (row.caseId !== id) continue;
    requireEvidence(row.status === "ok" && row.checks && Object.keys(row.checks).length === checks.length
      && checks.every(k => Object.hasOwn(row.checks,k) && typeof row.checks[k] === "boolean"), "A selected trial or check is incomplete.");
    const trial = await readJson(join(directory, "run-" + String(index + 1).padStart(3,"0") + ".json"), budget);
    requireEvidence(trial.kind === "local-workflow-run" && Object.hasOwn(trial, "output") && canonical(trial.run) === canonical(row), "A selected trial disagrees with its saved run.");
    outputs[row.variant][row.repetition] = trial.output;
    rows.push(row);
  }
  requireEvidence(seen.size === plan.cases.length * plan.repetitions * 2, "One or more recorded trials are missing.");
  return { frozen, plan, sources, dependencies, selected, rows, outputs };
}

function bindSource(run, prefix) {
  // A journal can describe files. It can never direct this process to load code from them.
  const service = dirname(run.frozen.config);
  requireEvidence(run.frozen.config === join(service, "observe.workflow.mjs"), "The saved workflow has an unsupported location.");
  const files = new Map();
  let remainingBytes = 16 * 1024 * 1024;
  for (const [path, digest] of run.sources) {
    const local = relative(service, path);
    if (path.replaceAll("\\", "/").includes("/node_modules/@tokensand/observability/")) continue;
    requireEvidence(local && !isAbsolute(local) && !local.startsWith("..") && hash.test(digest), "A declared application source is outside this service.");
    const bytes = git("show", run.plan.sourceGitCommit + ":" + prefix + local.split(sep).join("/"));
    remainingBytes -= bytes.length;
    requireEvidence(remainingBytes >= 0 && files.size < 128 && sha(bytes) === digest, "Declared sources do not match their recorded Git revision or exceed the review limit.");
    files.set(local, bytes);
  }
  return files;
}

// Expected SHA-256 of JSON.stringify([[file, sha256], ...]) in lexical filename order.
// Only identifiers and the aggregate digest of the 0.7.7 release are distributed here.
const runtimeFiles = [
  "cli-gate.mjs", "cli-handoff.mjs", "cli-plan-validation.mjs", "cli-verification.mjs", "cli.mjs",
  "dist/deno/index.js", "dist/v2/bedrock.js", "dist/v2/index.js", "dist/v2/metadata.js", "dist/v2/tool-evidence.js",
  "dist/workflows/bedrock.js", "dist/workflows/index.js", "dist/workflows/result-evidence.js", "dist/workflows/types.js",
  "dist/workflows/verification-types.js", "dist/workflows/verification.js", "package.json",
];
const expectedRuntime = "2e9b381dacbbeebc0bde557f36289d97fb84826585ee41db56bf2c1264f6181e";

async function verifiedSdk() {
  let entry;
  try {
    // Resolve in the consumer service without evaluating its package or trusting a journal path.
    const resolved = execFileSync(process.execPath, ["--input-type=module", "-e",
      "process.stdout.write(import.meta.resolve('@tokensand/observability/workflows'))"], { env, stdio: ["ignore","pipe","ignore"], timeout: 5000, encoding: "utf8" });
    entry = await realpath(fileURLToPath(resolved));
  } catch { throw new Unknown("Install your approved private @tokensand/observability 0.7.7 SDK in this candidate service. Use Build & Evaluate → Connect app for the team's pinned download."); }
  const base = dirname(dirname(dirname(entry)));
  requireEvidence(relative(base, entry) === join("dist", "workflows", "index.js"), "Use the supported private Node SDK 0.7.7 runtime.");
  const digests = new Map();
  for (const name of runtimeFiles) {
    const path = join(base, name);
    requireEvidence(await realpath(path) === path, "The installed SDK includes an unexpected linked runtime file.");
    const file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
    try {
      const info = await file.stat();
      requireEvidence(info.isFile() && info.size <= 8 * 1024 * 1024, "The installed SDK runtime is invalid.");
      digests.set(name, sha(await file.readFile()));
    } finally { await file.close(); }
  }
  requireEvidence(sha(JSON.stringify([...digests])) === expectedRuntime, "The installed SDK differs from the verified 0.7.7 release.");
  const {canonical} = await import(pathToFileURL(join(base,"cli-gate.mjs")).href);
  const {validateExperimentPlan} = await import(pathToFileURL(join(base,"cli-plan-validation.mjs")).href);
  return { url:pathToFileURL(entry).href, base, digests, canonical, validateExperimentPlan };
}

function verifyRecordedSdk(run, sdk) {
  const marker = "/node_modules/@tokensand/observability/";
  const frozen = new Map();
  for (const [path, digest] of run.sources) {
    const normalized = path.replaceAll("\\", "/");
    if (!normalized.includes(marker)) continue;
    const name = normalized.slice(normalized.lastIndexOf(marker) + marker.length);
    requireEvidence(!frozen.has(name), "The historical SDK contains duplicate runtime entries.");
    frozen.set(name, digest);
  }
  requireEvidence(frozen.size === sdk.digests.size && [...sdk.digests].every(([name, digest]) => frozen.get(name) === digest),
    "Both recorded runs must match the verified Node SDK 0.7.7 runtime.");
}

async function scoreSaved(before, after, id, workflowsUrl, cwd) {
  // The immutable v1 reviewer's structured worker invokes the pinned SDK's original scoring semantics.
  const child = fork(workerPath, ["--score-outputs", id], { cwd, execArgv: [], stdio: ["ignore","ignore","ignore","ipc"], env, serialization: "advanced" });
  let timer;
  try {
    return await new Promise((resolve, reject) => {
      const fail = () => reject(new Unknown("The trusted local scorer could not verify both sets of saved outputs."));
      timer = setTimeout(fail, 30000);
      child.once("message", resolve);
      child.once("error", fail);
      child.once("exit", fail);
      child.send({ workflowsUrl, definition: { workflow: after.plan.workflow, checks: after.plan.checks,
        evaluator: after.frozen.functionDigests.evaluator, dependencies: after.dependencies,
        repetitions: after.plan.repetitions, timeoutMs: after.plan.timeoutMs }, before: before.outputs, after: after.outputs }, error => { if (error) fail(); });
    });
  } finally { clearTimeout(timer); child.kill("SIGKILL"); }
}

async function replayReference(before, after, id, sdk, files, prefix) {
  // No candidate application dependencies are visible to the historical scorer. Undeclared
  // imports fail closed. A changed helper cannot make its own new failure appear green.
  const directory = await mkdtemp(join(tmpdir(), "tokensand-reference-scorer-"));
  try {
    if (!files.has("package.json") && git("ls-tree", before.plan.sourceGitCommit, "--", "package.json").length) {
      files.set("package.json", git("show", before.plan.sourceGitCommit + ":" + prefix + "package.json"));
    }
    for (const [name, bytes] of files) {
      const file = join(directory, name);
      await mkdir(dirname(file), { recursive: true, mode: 0o700 });
      await writeFile(file, bytes, { flag: "wx", mode: 0o600 });
    }
    const deps = join(directory, "node_modules", "@tokensand");
    await mkdir(deps, { recursive: true, mode: 0o700 });
    await symlink(sdk.base, join(deps, "observability"), process.platform === "win32" ? "junction" : "dir");
    return await scoreSaved(before, after, id, sdk.url, directory);
  } finally { await rm(directory, { recursive: true, force: true }); }
}

function verifiedScore(run, rescored, input, canonical) {
  const inputHash = createHmac("sha256", run.frozen.privateInputKey).update(canonical(input)).digest("hex");
  requireEvidence(inputHash === run.selected.inputSha256, "The selected case input differs between the runs or from the trusted checkout.");
  const next = new Map(rescored.map(row => [row.variant + "/" + row.repetition, row]));
  requireEvidence(next.size === run.rows.length && run.rows.every(row =>
    canonical(next.get(row.variant + "/" + row.repetition)?.checks) === canonical(row.checks)), "The original checks did not reproduce the recorded scores.");
  requireEvidence(run.rows.filter(r => r.variant === "baseline").every(r => Object.values(r.checks).every(Boolean)), "A selected baseline trial failed.");
  const candidate = run.rows.filter(r => r.variant === "candidate");
  return { passed: candidate.filter(r => Object.values(r.checks).every(Boolean)).length, total: candidate.length };
}

function toolSummary(run, approved) {
  const rows = run.rows.filter(r => r.variant === "candidate");
  const recorded = rows.filter(r => r.toolSpans !== undefined);
  const spans = recorded.flatMap(r => {
    requireEvidence(Array.isArray(r.toolSpans) && r.toolSpans.length <= 128, "Recorded tool metadata is invalid.");
    return r.toolSpans;
  });
  const labels = approved.map(name => {
    const matches = spans.filter(s => s?.name === name);
    const durations = matches.map(s => {
      requireEvidence(["ok","error","interrupted"].includes(s.status) && Number.isFinite(s.durationMs) && s.durationMs >= 0, "Recorded tool metadata is invalid.");
      return s.durationMs;
    }).sort((a,b) => a-b);
    const middle = Math.floor(durations.length / 2);
    const median = durations.length ? (durations[middle] + durations[Math.floor((durations.length - 1) / 2)]) / 2 : null;
    return { name, recorded: matches.length, returned: matches.filter(s => s.status === "ok").length,
      errors: matches.filter(s => s.status === "error").length, interrupted: matches.filter(s => s.status === "interrupted").length, medianMs: median === null ? null : Math.round(median * 10) / 10 };
  });
  return { trialsWithToolRecords: recorded.length, totalTrials: rows.length, labels };
}

async function main() {
  const {values, positionals} = parseArgs({ allowPositionals: true, options: {
    reference: { type: "string" }, case: { type: "string" }, "include-tool": { type: "string", multiple: true }, help: { type: "boolean" },
  } });
  if (values.help) { console.log(help); return 0; }
  const id = values.case;
  const approved = [...new Set(values["include-tool"] ?? [])];
  requireEvidence(positionals.length === 2 && caseId.test(id ?? "") && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,159}$/.test(values.reference ?? "")
    && approved.length <= 12 && approved.every(name => toolName.test(name) && !/(?:^|[^a-z0-9])(?:sk[-_]|tobs_|dai_|tvly-)/i.test(name)), "Supply two local run directories, an explicit Git reference and case ID. Use --help for the exact options.");
  let worker;
  try { worker = await readFile(workerPath); }
  catch { throw new Unknown("Place the public review-repair-v1.mjs file beside review-release-reference-v1.mjs and rerun."); }
  requireEvidence(sha(worker) === "3c31c407b908f17b61491ae858267b1fff16d1eb844eb529c8e23c7618e3ad11", "Restore the verified public review-repair-v1.mjs companion beside this reviewer.");
  const sdk = await verifiedSdk();
  const { canonical } = sdk;
  const budget = {remaining:32*1024*1024};
  const before = await readRun(positionals[0], id, budget, sdk);
  const after = await readRun(positionals[1], id, budget, sdk);
  verifyRecordedSdk(before,sdk); verifyRecordedSdk(after,sdk);
  const current = git("rev-parse","HEAD").toString().trim();
  requireEvidence(git("status","--porcelain","--untracked-files=no").length === 0 && current === after.plan.sourceGitCommit, "Use a clean checkout of the candidate revision.");
  const reference = git("rev-parse","--verify","--end-of-options",values.reference + "^{commit}").toString().trim();
  requireEvidence(reference === before.plan.sourceGitCommit && reference !== current, "The selected reference must identify the distinct earlier run.");
  git("merge-base","--is-ancestor",reference,current);
  const prefix = git("rev-parse","--show-prefix").toString().trim();
  const source = bindSource(before,prefix);
  bindSource(after,prefix);
  requireEvidence(sha(await readFile("observe.workflow.mjs")) === after.sources.get(after.frozen.config), "The trusted service workflow differs from the recorded candidate.");
  requireEvidence(before.plan.workflow === after.plan.workflow && before.plan.scope === after.plan.scope
    && before.plan.repetitions === after.plan.repetitions && before.plan.timeoutMs === after.plan.timeoutMs, "The workflow scope or trial settings changed.");
  requireEvidence(before.sources.get(before.frozen.config) === after.sources.get(after.frozen.config)
    && before.plan.checksVersion === after.plan.checksVersion && canonical(before.plan.checks) === canonical(after.plan.checks)
    && before.frozen.functionDigests.evaluator === after.frozen.functionDigests.evaluator && canonical(before.dependencies) === canonical(after.dependencies),
    "The workflow definition, checks or declared scorer dependencies changed.");
  const rescore = await replayReference(before,after,id,sdk,source,prefix);
  const prior = verifiedScore(before,rescore.before,rescore.input,canonical);
  const later = verifiedScore(after,rescore.after,rescore.input,canonical);
  requireEvidence(prior.passed === prior.total, "The selected reference case was already failing.");
  const verdict = later.passed === later.total ? "still_passing" : "regressed";
  const report = { kind:"local-release-reference", verdict, case:id, reference:{ revision:reference, ...prior }, candidate:{ revision:current, ...later },
    provenance:"Developer-selected Git reference, scored from local evidence." };
  if (approved.length) report.tools = { reference:toolSummary(before,approved), candidate:toolSummary(after,approved),
    interpretation:"Only recorded callbacks with the approved labels are summarized. Missing records do not establish absence or causality." };
  console.log(JSON.stringify(report,null,2));
  return verdict === "regressed" ? 100 : 0;
}

try { process.exitCode = await main(); }
catch (error) {
  console.log(JSON.stringify({ kind:"local-release-reference", verdict:"unknown", reason:error instanceof Unknown ? error.message : "Unable to verify local evidence. Check the revisions, private journals and pinned Node SDK." }));
  process.exitCode = 2;
}
