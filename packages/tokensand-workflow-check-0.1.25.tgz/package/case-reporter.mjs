// Node 20 exposes late callback errors as diagnostics, outside the scored cases.
export function isLateCallbackError(type, data) {
  return type === "test:diagnostic" && data.nesting === 0 &&
    /generated asynchronous activity after the test ended[\s\S]* triggered an (?:uncaughtException|unhandledRejection) event\.$/.test(data.message);
}

export function hasFailedAndUnscoredChecks(data) {
  return data.details?.error?.cause?.code === "TOKENSAND_FAILED_AND_UNSCORED";
}

export function hasUnscoredChecks(data) {
  return hasFailedAndUnscoredChecks(data) || data.details?.error?.cause?.code === "TOKENSAND_UNSCORED";
}

export function hasScorerError(data) {
  return hasUnscoredChecks(data) && data.details.error.cause.scorerError === true;
}

// Node's test runner owns execution, timeouts and the exit code.
export default async function* reportCases(events) {
  let passed = 0;
  let failed = 0;
  let skipped = 0;
  let incomplete = 0;
  let alsoIncomplete = 0;
  let lateError = false;
  for await (const { type, data } of events) {
    if (isLateCallbackError(type, data)) lateError = true;
    if (type !== "test:pass" && type !== "test:fail") continue;
    if (data.skip || data.todo) {
      skipped++;
    } else if (type === "test:pass") {
      passed++;
    } else {
      const mixed = hasFailedAndUnscoredChecks(data);
      const incompleteOnly = !mixed && hasUnscoredChecks(data);
      if (incompleteOnly) incomplete++;
      else failed++;
      if (mixed) alsoIncomplete++;
      const error = data.details.error;
      // The starter asserts that the failed-check count equals zero. Keep its
      // complete list of scorer labels and drop the redundant numeric diff.
      const reason = error.message.replace(/\n\n\d+ !== 0\s*$/, "").trim();
      yield `${incompleteOnly ? "INCOMPLETE" : "FAIL"} ${data.name} — ${reason.replace(/\s+/g, " ")}\n`;
    }
  }
  if (passed + failed + skipped + incomplete > 0) {
    const overlap = alsoIncomplete ? ` (${alsoIncomplete} also incomplete)` : "";
    const counts = [`${passed} passed`, `${failed} failed${overlap}`];
    if (incomplete) counts.push(`${incomplete} incomplete${alsoIncomplete ? " only" : ""}`);
    if (skipped) counts.push(`${skipped} skipped or todo`);
    yield counts.join(", ") + "\n";
    if (lateError) {
      yield "Workflow failed after a case finished. Await outstanding callbacks. Append --verbose for the local error.\n";
    } else if (alsoIncomplete || (failed && incomplete)) {
      yield "Fix the workflow and restore the unscored checks, then rerun.\n";
    } else if (incomplete) {
      yield "Restore the unscored checks before reviewing the result.\n";
    } else if (!failed && process.exitCode && process.exitCode !== 2) {
      yield "Workflow failed outside the scored cases. Append --verbose for local diagnostics.\n";
    } else if (failed) yield "Add --inspect-values to a focused run to save private expected and actual values, or --verbose for full Node test output.\n";
  }
}
