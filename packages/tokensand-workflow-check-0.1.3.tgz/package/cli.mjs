#!/usr/bin/env node
import { constants, copyFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const starter = fileURLToPath(new URL("./first-check-v3.mjs", import.meta.url));
const args = process.argv.slice(2);
const verbose = args.at(-1) === "--verbose";
if (verbose) args.pop();
let runner = starter;
if (args.some(arg => arg === "--case" || arg.startsWith("--case=")) &&
    !args.some(arg => arg === "--offline-workflow" || arg.startsWith("--offline-workflow="))) {
  args.unshift("--offline-workflow", "./tokensand-first.test.mjs");
}
if (args.length === 0) {
  runner = resolve("tokensand-first.test.mjs");
  try {
    copyFileSync(starter, runner, constants.COPYFILE_EXCL);
    console.log("Created tokensand-first.test.mjs. Edit the planner, then rerun with node tokensand-first.test.mjs.");
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
  }
}
const reporter = new URL("./case-reporter.mjs", import.meta.url).href;
const nodeArgs = verbose ? [] : ["--test-reporter=" + reporter];
const result = spawnSync(process.execPath, [...nodeArgs, runner, ...args], { stdio: "inherit" });
if (result.error) throw result.error;
process.exitCode = result.status ?? 1;
