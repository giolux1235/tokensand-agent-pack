// Node's test runner owns execution, timeouts and the exit code.
export default async function* reportCases(events) {
  let passed = 0;
  let failed = 0;
  let skipped = 0;
  for await (const { type, data } of events) {
    if (type !== "test:pass" && type !== "test:fail") continue;
    if (data.skip || data.todo) {
      skipped++;
    } else if (type === "test:pass") {
      passed++;
    } else {
      failed++;
      const error = data.details.error;
      // The starter asserts that the failed-check count equals zero. Keep its
      // complete list of scorer labels and drop the redundant numeric diff.
      const reason = error.message.replace(/\n\n\d+ !== 0\s*$/, "").trim();
      yield `FAIL ${data.name} — ${reason.replace(/\s+/g, " ")}\n`;
    }
  }
  if (passed + failed + skipped > 0) {
    yield `${passed} passed, ${failed} failed${skipped ? `, ${skipped} skipped or todo` : ""}\n`;
    if (failed) yield "Repeat one case with --case CASE_ID. Append --verbose for the full Node test output.\n";
  }
}
