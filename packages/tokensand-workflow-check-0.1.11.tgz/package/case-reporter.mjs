// Node 20 exposes late callback errors as diagnostics, outside the scored cases.
export function isLateCallbackError(type, data) {
  return type === "test:diagnostic" && data.nesting === 0 &&
    /generated asynchronous activity after the test ended[\s\S]* triggered an (?:uncaughtException|unhandledRejection) event\.$/.test(data.message);
}

export function hasUnscoredChecks(data) {
  return data.details?.error?.cause?.code === "TOKENSAND_UNSCORED";
}

// Node's test runner owns execution, timeouts and the exit code.
export default async function* reportCases(events) {
  let passed = 0;
  let failed = 0;
  let skipped = 0;
  let incomplete = 0;
  let lateError = false;
  for await (const { type, data } of events) {
    if (isLateCallbackError(type, data)) lateError = true;
    if (type !== "test:pass" && type !== "test:fail") continue;
    if (data.skip || data.todo) {
      skipped++;
    } else if (type === "test:pass") {
      passed++;
    } else {
      const unscored = hasUnscoredChecks(data);
      if (unscored) incomplete++;
      else failed++;
      const error = data.details.error;
      // The starter asserts that the failed-check count equals zero. Keep its
      // complete list of scorer labels and drop the redundant numeric diff.
      const reason = error.message.replace(/\n\n\d+ !== 0\s*$/, "").trim();
      yield `${unscored ? "INCOMPLETE" : "FAIL"} ${data.name} — ${reason.replace(/\s+/g, " ")}\n`;
    }
  }
  if (passed + failed + skipped + incomplete > 0) {
    yield `${passed} passed, ${failed} failed${incomplete ? `, ${incomplete} incomplete` : ""}${skipped ? `, ${skipped} skipped or todo` : ""}\n`;
    if (lateError) {
      yield "Workflow failed after a case finished. Await outstanding callbacks. Append --verbose for the local error.\n";
    } else if (incomplete) {
      yield "Restore the unscored checks and repeat the case with --case CASE_ID.\n";
    } else if (!failed && process.exitCode && process.exitCode !== 2) {
      yield "Workflow failed outside the scored cases. Append --verbose for local diagnostics.\n";
    } else if (failed) yield "Repeat one case with --case CASE_ID. Add --inspect-values to save private expected and actual values, or --verbose for full Node test output.\n";
  }
}
