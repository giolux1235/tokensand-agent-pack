// Offline document. Only fields used in the recipient's release note may leave the author.
const labels = { regressed: 'Regressed', still_passing: 'Still passing', unknown: 'Inconclusive' };
const credentialLike = /(?:^|[^a-z0-9])(?:sk[-_]|tobs_|dai_|tvly-|gh[pousr]_|github_pat_|xox[aboprs]-)|(?:^|[^A-Za-z0-9])AKIA[0-9A-Z]{16}/i;
const checkerArchive = 'https://github.com/giolux1235/tokensand-agent-pack/releases/download/workflow-check-0.1.18/tokensand-workflow-check-0.1.18.tgz';
const fallbackReason = 'The available evidence could not verify this case.';
const publicReason = 'Selected evidence could not be verified. Check the local revisions, setup and original trials.';

const textEscapes = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escapeHtml = text => text.replace(/[&<>"']/g, ch => textEscapes[ch]);
const escapeJson = value => JSON.stringify(value).replace(/[<>&\u2028\u2029]/g, ch =>
  '\\u' + ch.charCodeAt(0).toString(16).padStart(4, '0'));

function requireNote(ok) {
  if (!ok) throw new Error('The release note contains an unsupported case, revision or score.');
}

function counts(value) {
  requireNote(value && Number.isInteger(value.passed) && Number.isInteger(value.total) &&
    value.total >= 3 && value.total <= 10 && value.passed >= 0 && value.passed <= value.total);
  return { passed: value.passed, total: value.total };
}

function publicNote(input) {
  const revision = value => typeof value === 'string' && /^[a-f0-9]{40}$/.test(value);
  requireNote(input?.kind === 'tokensand-release-note' && input.schemaVersion === 1 &&
    ['all-recorded-cases', 'selected-cases'].includes(input.selection) &&
    revision(input.referenceRevision) && revision(input.candidateRevision) && input.referenceRevision !== input.candidateRevision &&
    Array.isArray(input.cases) && input.cases.length > 0 && input.cases.length <= 20);
  const ids = new Set();
  const cases = input.cases.map(row => {
    requireNote(typeof row?.id === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(row.id) &&
      !credentialLike.test(row.id) && !ids.has(row.id) && typeof row.verdict === 'string' && Object.hasOwn(labels, row.verdict));
    ids.add(row.id);
    const reviewed = { id: row.id, verdict: row.verdict };
    if (row.reference !== undefined) reviewed.reference = counts(row.reference);
    if (row.candidate !== undefined) reviewed.candidate = counts(row.candidate);
    if (row.verdict !== 'unknown') {
      requireNote(reviewed.reference && reviewed.candidate && reviewed.reference.total === reviewed.candidate.total &&
        reviewed.reference.passed === reviewed.reference.total &&
        (row.verdict === 'still_passing') === (reviewed.candidate.passed === reviewed.candidate.total));
    } else if (row.reason !== undefined) {
      reviewed.reason = row.reason === publicReason ? publicReason : fallbackReason;
    }
    return reviewed;
  });
  return { kind: input.kind, schemaVersion: 1, selection: input.selection, referenceRevision: input.referenceRevision,
    candidateRevision: input.candidateRevision, cases };
}

const styles = `
:root { color-scheme: light; --ink:#182722; --muted:#50645a; --line:#d9e2dc; --paper:#fff; --bg:#f3f7f3; }
* { box-sizing:border-box; }
body { margin:0; background:var(--bg); color:var(--ink); font:1rem/1.5 system-ui,-apple-system,sans-serif; }
main { width:min(100%,56rem); margin:0 auto; padding:2.75rem 1.5rem 4rem; }
header { border-bottom:1px solid var(--line); padding-bottom:1rem; display:flex; align-items:center; gap:.8rem; }
.brand { font-weight:750; letter-spacing:-.05em; font-size:1.25rem; }
header span+span { border-left:1px solid var(--line); padding-left:.8rem; color:var(--muted); }
h1 { font-size:clamp(1.8rem,4vw,2.85rem); line-height:1.12; letter-spacing:-.045em; margin:1.65rem 0 .45rem; }
h2 { font-size:1.13rem; margin:0 0 .65rem; }
p,dl,dd,pre,ol { margin:0; }
.scope,.muted { color:var(--muted); }
.revisions { display:grid; grid-template-columns:1fr 1fr; gap:.8rem; margin:1.3rem 0 1.85rem; }
.revisions div { min-width:0; border-left:3px solid #bacdbf; padding:.1rem .75rem; }
dt { font-size:.78rem; color:var(--muted); font-weight:650; }
code { font-family:ui-monospace,SFMono-Regular,Consolas,monospace; overflow-wrap:anywhere; }
.revisions code { font-size:.83rem; }
.cases { list-style:none; padding:0; display:grid; gap:.65rem; }
.case { padding:1rem 1.15rem; border:1px solid var(--line); border-radius:.75rem; background:var(--paper); min-width:0; }
.case-heading { display:flex; align-items:center; flex-wrap:wrap; gap:.5rem .8rem; margin-bottom:.55rem; }
h3 { font-size:1rem; line-height:1.3; margin:0; min-width:0; }
h3 code { font-size:.95rem; }
.badge { font-size:.75rem; line-height:1.35; font-weight:700; padding:.2rem .5rem; border-radius:.35rem; }
.regressed { color:#842f27; background:#fbe8e5; }.still_passing { color:#145438; background:#e0f1e7; }.unknown { color:#694b0f; background:#f8edd6; }
.scores { display:flex; flex-wrap:wrap; gap:.45rem 1.4rem; font-size:.91rem; }
.scores div { display:flex; align-items:baseline; gap:.4rem; }.scores dt { font-size:.85rem; font-weight:normal; }
.scores dd { font-weight:675; font-variant-numeric:tabular-nums; }.reason { margin:.4rem 0; font-size:.9rem; }
details { margin-top:.6rem; } summary { cursor:pointer; color:#1a5840; width:fit-content; font-size:.88rem; font-weight:650; padding:.15rem .15rem .15rem 0; }
summary:focus-visible { outline:2px solid #176e49; outline-offset:3px; border-radius:2px; }
pre { margin-top:.4rem; padding:.65rem .75rem; background:var(--bg); border-radius:.35rem; font-size:.83rem; white-space:pre-wrap; overflow-wrap:anywhere; }
.command-label { margin-top:.65rem; color:var(--muted); font-size:.82rem; }
footer { margin-top:1.25rem; color:var(--muted); font-size:.88rem; }
@media(max-width:36rem){main{padding:1.25rem 1rem 2.5rem}.revisions{grid-template-columns:minmax(0,1fr);gap:.65rem}.case{padding:.8rem .9rem}summary{padding:.5rem 0}}
@media print { body{background:white}main{max-width:none;padding:0}.case{break-inside:avoid} }
`;

function caseItem(row, open) {
  const number = score => score ? score.passed + '/' + score.total : 'Unavailable';
  // A leading hyphen needs the unambiguous form accepted by Node's argument parser.
  const option = row.id.startsWith('-') ? '--case=' + row.id : '--case ' + row.id;
  const args = '--recheck-release ./review.html ' + option + ' --run';
  const command = 'npx --yes ' + checkerArchive + ' ' + args;
  return `<li class="case"><div class="case-heading"><h3><code>${escapeHtml(row.id)}</code></h3><span class="badge ${row.verdict}">${labels[row.verdict]}</span></div>
<dl class="scores"><div><dt>Reference passed</dt><dd>${number(row.reference)}</dd></div><div><dt>Candidate passed</dt><dd>${number(row.candidate)}</dd></div></dl>
${row.reason ? '<p class="reason muted">' + escapeHtml(row.reason) + '</p>' : ''}
<details${open ? ' open' : ''}><summary aria-label="Replay this case (${escapeHtml(row.id)})">Replay this case</summary><p class="command-label">Downloads the pinned checker on first use.</p><pre><code>${escapeHtml(command)}</code></pre><p class="command-label">If you already have this checker installed, replay offline.</p><pre><code>tokensand-check ${escapeHtml(args)}</code></pre></details></li>`;
}

export function renderReleaseNote(input) {
  const note = publicNote(input);
  const { cases } = note;
  const regressed = cases.filter(c => c.verdict === 'regressed').length;
  const unknown = cases.filter(c => c.verdict === 'unknown').length;
  const title = regressed ? `${regressed} ${regressed === 1 ? 'case' : 'cases'} regressed`
    : unknown ? `${unknown} ${unknown === 1 ? 'case needs' : 'cases need'} more evidence`
    : `${cases.length === 1 ? 'The selected case still passes' : 'All selected cases still pass'}`;
  const scope = note.selection === 'all-recorded-cases' ? 'recorded' : 'selected';
  const priority = { regressed: 0, unknown: 1, still_passing: 2 };
  const displayCases = [...cases].sort((a, b) => priority[a.verdict] - priority[b.verdict]);
  const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)} | Tokens&amp; release review</title><style>${styles}</style></head>
<body><main><header><span class="brand">Tokens&amp;</span><span>Release review</span></header>
<h1>${escapeHtml(title)}</h1><p class="scope">${cases.length} ${scope} ${cases.length === 1 ? 'case' : 'cases'} reviewed against the selected Git reference.</p>
<dl class="revisions"><div><dt>Reference revision</dt><dd><code>${note.referenceRevision}</code></dd></div><div><dt>Candidate revision</dt><dd><code>${note.candidateRevision}</code></dd></div></dl>
<section aria-labelledby="case-title"><h2 id="case-title">Case results</h2><ol class="cases">${displayCases.map((row, index) => caseItem(row, index === 0)).join('\n')}</ol></section>
<footer>Save this file as <code>review.html</code> in your trusted candidate checkout to replay a case. Use your release records to confirm which revision was deployed.${cases.length > 1 ? `<details><summary>Replay all ${cases.length} cases in this note</summary><pre><code>npx --yes ${checkerArchive} --recheck-release ./review.html --all-cases --run</code></pre></details>` : ''}</footer>
</main><script id="tokensand-release-note" type="application/json">${escapeJson(note)}</script></body></html>`;
  if (new TextEncoder().encode(html).byteLength > 128 * 1024) throw new Error('Choose fewer cases to keep the HTML release note within 128 KiB.');
  return html;
}
