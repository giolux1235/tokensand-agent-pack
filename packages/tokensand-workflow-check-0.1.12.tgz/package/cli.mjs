#!/usr/bin/env node
import { constants, copyFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const starter = fileURLToPath(new URL("./agent-check.mjs", import.meta.url));
const args = process.argv.slice(2);
if (args.length === 1 && args[0] === "--pr-receipt") {
  const { starterReview } = await import("./starter-pr.mjs");
  process.exit(starterReview("record"));
}
const verbose = args.at(-1) === "--verbose";
if (verbose) args.pop();
let runner = starter;
if (args.includes("--install-test")) {
  const github = args.length === 2 && args.includes("--github");
  if (args.length !== 1 && !github) {
    console.error("Run --install-test, optionally with --github, from the directory containing observe.workflow.mjs.");
    process.exit(2);
  }
  try {
    const { installTest } = await import("./install-test.mjs");
    runner = resolve(installTest(github));
  } catch (error) {
    console.error("Tokens& setup: " + error.message);
    process.exit(2);
  }
  args.splice(0, args.length, "--offline-workflow", "./observe.workflow.mjs");
}
if (args.some(arg => arg === "--case" || arg.startsWith("--case=")) &&
    !args.some(arg => arg === "--offline-workflow" || arg.startsWith("--offline-workflow="))) {
  args.unshift("--offline-workflow", "./tokensand-first.test.mjs");
}
if (args.length === 0) {
  runner = resolve("tokensand-first.test.mjs");
  try {
    copyFileSync(starter, runner, constants.COPYFILE_EXCL);
    console.log("Created tokensand-first.test.mjs. Edit the planner, then rerun with node tokensand-first.test.mjs.");
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
  }
}
const reporter = new URL("./case-reporter.mjs", import.meta.url).href;
const nodeArgs = verbose ? [] : ["--test-reporter=" + reporter];
// This is an independent CLI run, including when a parent Node test spawned it.
// A parent test-runner context can replace our reporter with binary IPC output.
const env = { ...process.env };
delete env.NODE_TEST_CONTEXT;
const result = spawnSync(process.execPath, [...nodeArgs, runner, ...args], { stdio: "inherit", env });
if (result.error) throw result.error;
process.exitCode = result.status ?? 1;
