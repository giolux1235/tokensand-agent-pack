"""Command-line entry point for the public native workflow test."""
from pathlib import Path
import subprocess
import sys


def main():
    starter = Path(__file__).with_name("tokensand_check_starter.py")
    args = sys.argv[1:]
    runner = starter
    compare = any(len(arg) > 2 and arg.startswith("--") and "--compare-baseline".startswith(arg) for arg in args)
    if compare:
        import runpy
        return runpy.run_path(str(starter))["main"](args)
    if any(arg == "--case" or arg.startswith("--case=") for arg in args) and not any(
            arg == "--offline-workflow" or arg.startswith("--offline-workflow=") for arg in args):
        if not Path("test_tokensand_first.py").is_file():
            print("Supply --offline-workflow PATH or run python3 -m tokensand_check to create test_tokensand_first.py.", file=sys.stderr)
            return 2
        args = ["--offline-workflow", "test_tokensand_first.py", *args]
    if not args:
        runner = Path("test_tokensand_first.py")
        contents = starter.read_bytes()
        try:
            with runner.open("xb") as output:
                output.write(contents)
            print("Created test_tokensand_first.py. Edit the planner, then rerun with python3 test_tokensand_first.py.", flush=True)
        except FileExistsError:
            pass
    return subprocess.call([sys.executable, str(runner), *args])


if __name__ == "__main__":
    raise SystemExit(main())
