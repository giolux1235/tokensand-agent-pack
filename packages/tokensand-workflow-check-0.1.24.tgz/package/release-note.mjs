// A local handoff contains selected scores and revisions only. The core validates the original private trials.
import { execFile } from 'node:child_process';
import { constants } from 'node:fs';
import { link, mkdtemp, open, rm, writeFile } from 'node:fs/promises';
import { dirname, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs, promisify } from 'node:util';

const execute = promisify(execFile);
const core = fileURLToPath(new URL('./review-release-reference-v2.mjs', import.meta.url));
const idPattern = /^[A-Za-z0-9_-]{1,80}$/;
const revisionPattern = /^[0-9a-f]{40}$/;
const credentialShape = /(?:^|[^a-z0-9])(?:sk[-_]|tobs_|dai_|tvly-|gh[pousr]_|github_pat_|xox[aboprs]-)|(?:^|[^A-Za-z0-9])AKIA[0-9A-Z]{16}/i;
const shareableId = id => typeof id === 'string' && idPattern.test(id) && !credentialShape.test(id);
const failedReference = 'The selected reference case was already failing.';
const maximumCases = 20; // Two SDK v1 plans contain at most ten cases each.
const maxNoteBytes = 128 * 1024;
const usage = 'Use --review-release REFERENCE_RUN CANDIDATE_RUN --reference TAG_OR_SHA with --all-cases or one or more --case ID. Add --note review.html or --note review.json to create a shareable local file.';
class ReviewError extends Error {}
function check(value, message) { if (!value) throw new ReviewError(message); }
async function listCases(directory) {
  const file = await open(join(directory,'plan.json'), constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  try {
    const stat = await file.stat();
    check(stat.isFile() && stat.size <= 8 * 1024 * 1024, 'Choose a regular frozen local plan under 8 MiB.');
    const frozen = JSON.parse(await file.readFile('utf8')), cases = frozen?.plan?.cases;
    check(frozen?.schemaVersion === 1 && frozen.plan?.schemaVersion === 1 && Array.isArray(cases) && cases.length > 0 && cases.length <= 10,
      'Use a version 1 frozen SDK plan with one to ten cases.');
    const ids = cases.map(row => row?.id);
    check(ids.every(shareableId) && new Set(ids).size === ids.length, 'A frozen plan contains duplicate or unsupported case IDs. Select a valid plan.');
    return ids;
  } finally { await file.close(); }
}
function validArm(arm) {
  return arm && revisionPattern.test(arm.revision) && Number.isInteger(arm.total) && arm.total >= 3 && arm.total <= 10
    && Number.isInteger(arm.passed) && arm.passed >= 0 && arm.passed <= arm.total;
}
async function scoreCase(directories, reference, id) {
  const args = [core,'--reference',reference,'--case='+id,'--',...directories];
  const options = { env:{PATH:process.env.PATH,SystemRoot:process.env.SystemRoot}, timeout:45000, maxBuffer:128*1024, encoding:'utf8' };
  let status = 0, output;
  try { output = (await execute(process.execPath,args,options)).stdout; }
  catch (error) { status = error.code; output = error.stdout; }
  const fallback = {id,verdict:'unknown',reason:'Selected evidence could not be verified. Check the local revisions, setup and original trials.'};
  try {
    const r = JSON.parse(output);
    if (r.kind !== 'local-release-reference') return fallback;
    if (status === 2 && r.verdict === 'unknown') {
      if (r.reason === failedReference) return { ...fallback, reason: failedReference };
      if (r.reason === 'The workflow definition, checks or declared scorer dependencies changed.') {
        return { ...fallback, reason: 'The scorer changed. Restore the original checks and run the candidate again.' };
      }
      return fallback;
    }
    if (r.case !== id || !validArm(r.reference) || !validArm(r.candidate) || r.reference.revision === r.candidate.revision ||
      r.reference.total !== r.candidate.total || r.reference.passed !== r.reference.total) return fallback;
    const passed = r.candidate.passed === r.candidate.total;
    if (r.verdict !== (passed ? 'still_passing' : 'regressed') || status !== (passed ? 0 : 100)) return fallback;
    return {id,verdict:r.verdict,reference:{passed:r.reference.passed,total:r.reference.total},
      candidate:{passed:r.candidate.passed,total:r.candidate.total},referenceRevision:r.reference.revision,candidateRevision:r.candidate.revision};
  } catch { return fallback; }
}
async function save(note, path) {
  const ext = extname(path).toLowerCase();
  const contents = ext === '.json' ? JSON.stringify(note,null,2)+'\n' : (await import('./release-note-html.mjs')).renderReleaseNote(note);
  check(Buffer.byteLength(contents) <= maxNoteBytes,'The selected cases exceed the portable note limit. Choose fewer cases.');
  // Render and bound the complete note before creating an exclusive local file.
  const temporary = await mkdtemp(join(dirname(path),'.tokensand-note-'));
  try {
    const file = join(temporary,'note');
    await writeFile(file,contents,{flag:'wx',mode:0o600});
    await link(file,path);
  } finally { await rm(temporary,{recursive:true,force:true}); }
}
export async function reviewRelease(argv) {
  try {
    const {values,positionals} = parseArgs({args:argv,allowPositionals:true,options:{
      reference:{type:'string'},case:{type:'string',multiple:true},'all-cases':{type:'boolean'},note:{type:'string'},help:{type:'boolean'}
    }});
    if (values.help) {console.log(usage);return 0;}
    const chosen = values.case ?? [], all = values['all-cases'] === true;
    check(positionals.length === 2 && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,159}$/.test(values.reference ?? '') &&
      (all ? chosen.length === 0 : chosen.length > 0 && chosen.length <= maximumCases && chosen.every(shareableId) && new Set(chosen).size === chosen.length),usage);
    check(values.note === undefined || ['.json','.html'].includes(extname(values.note).toLowerCase()),'Use a new .html or .json file for the local note.');
    let ids = chosen;
    if (all) {
      const [earlier,later] = await Promise.all(positionals.map(listCases));
      ids = [...new Set([...earlier,...later])];
      check(ids.length <= maximumCases, 'Both plans exceed the portable selection limit. Choose specific cases.');
    }
    const cases = [];
    let referenceRevision, candidateRevision;
    console.log((all ? 'Cases recorded in either frozen plan' : 'Selected cases')+' ('+ids.length+')');
    for (const id of ids) {
      const score = await scoreCase(positionals,values.reference,id);
      const {referenceRevision:ref,candidateRevision:cand,...row} = score;
      if (ref) {
        check(!referenceRevision || (referenceRevision === ref && candidateRevision === cand),
          'The source revisions changed during review. Repeat from stable local runs.');
        referenceRevision = ref; candidateRevision = cand;
      }
      cases.push(row);
      const outcome = row.verdict === 'unknown' ? 'unknown. '+row.reason
        : row.verdict.replace('_',' ')+'  '+row.reference.passed+'/'+row.reference.total+' → '+row.candidate.passed+'/'+row.candidate.total;
      console.log(row.id+'  '+outcome);
    }
    const selection = all ? 'all-recorded-cases' : 'selected-cases';
    if (!referenceRevision) {
      const failed = cases.find(row => row.reason === failedReference);
      if (failed) {
        console.log('No note was created. To review this repair, use the same checker and run directories with these arguments');
        console.log('--review-repair REFERENCE_RUN CANDIDATE_RUN --case '+failed.id);
        return 2;
      }
      console.log('No case verified the two revisions. Open the clean candidate checkout with the same approved Tokens& Node SDK (0.7.7 or 0.7.8) used for both runs. Check the reference tag and complete local run directories, then rerun. No note was created.');
      return 2;
    }
    if (values.note) {
      await save({kind:'tokensand-release-note',schemaVersion:1,selection,referenceRevision,candidateRevision,cases},values.note);
      console.log('Local '+extname(values.note).slice(1).toUpperCase()+' note created. Review it before sharing.');
    }
    return cases.some(c=>c.verdict==='regressed') ? 100 : cases.some(c=>c.verdict==='unknown') ? 2 : 0;
  } catch (error) {
    console.error(error instanceof ReviewError ? error.message : error?.code === 'EEXIST' ? 'The note already exists. Choose a new filename.' : 'Unable to complete the local release review. Check the files, pinned SDK and arguments.');return 2;
  }
}
