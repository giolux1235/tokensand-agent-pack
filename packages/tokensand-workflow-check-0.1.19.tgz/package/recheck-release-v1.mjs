// Offline recipient replay for a developer-selected release note. Only --run executes repository code.
import { execFileSync, fork } from 'node:child_process';
import { createHash } from 'node:crypto';
import { constants } from 'node:fs';
import { mkdtemp, open, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { isDeepStrictEqual, parseArgs } from 'node:util';

const here = fileURLToPath(import.meta.url);
const checker = fileURLToPath(new URL('./agent-check.mjs', import.meta.url));
const checkerHash = 'd3165fbb875d45c6f81624314e910fc727485a513c94fdc78bf59de37665f17e';
const caseId = /^[A-Za-z0-9_-]{1,80}$/;
const credentialShape = /(?:^|[^a-z0-9])(?:sk[-_]|tobs_|dai_|tvly-|gh[pousr]_|github_pat_|xox[aboprs]-)|(?:^|[^A-Za-z0-9])AKIA[0-9A-Z]{16}/i;
const shareableId = id => typeof id === 'string' && caseId.test(id) && !credentialShape.test(id);
const fullRevision = /^[a-f0-9]{40}$/;
const help = 'From your trusted service checkout: --recheck-release NOTE.json|NOTE.html (--case ID [--case ID ...] | --all-cases) [--reference TAG_OR_SHA] [--run]. Preview reads the note only. --run executes committed, self-contained offline app code on both revisions, in temporary clones, with the original scorer. Choose up to 20 distinct cases from one note. Each case runs three fresh trials per revision in separate checkouts. A regression in any selected case takes precedence over an inconclusive result. A fresh failure can confirm a regression. Passing three trials cannot clear a claim based on four to ten historical trials. Exit 0 still passing; 100 regressed; 2 inconclusive or awaiting replay.';
const env = { PATH:process.env.PATH, SystemRoot:process.env.SystemRoot, GIT_CONFIG_NOSYSTEM:'1', GIT_CONFIG_GLOBAL:process.platform === 'win32' ? 'NUL' : '/dev/null', GIT_TERMINAL_PROMPT:'0', GIT_ALLOW_PROTOCOL:'file', GIT_LFS_SKIP_SMUDGE:'1' };
class Inconclusive extends Error {}
function requireReplay(condition, message) { if (!condition) throw new Inconclusive(message); }
function safePrint(value) { process.stdout.write(JSON.stringify(value, null, 2) + '\n'); }
function git(cwd, ...args) {
  return execFileSync('git', ['--no-replace-objects', '-c','core.hooksPath=/dev/null', ...args], { cwd, env, stdio:['ignore','pipe','ignore'], timeout:30000, maxBuffer:1024 * 1024, encoding:'utf8' }).trim();
}
async function readNote(path) {
  const file = await open(path, constants.O_RDONLY | constants.O_NONBLOCK | constants.O_NOFOLLOW);
  try {
    const info = await file.stat();
    requireReplay(info.isFile() && info.size <= 128 * 1024, 'Choose a regular release-note JSON file under 128 KiB.');
    const text = await file.readFile('utf8');
    if (!text.trimStart().startsWith('<')) return JSON.parse(text);
    const marker = '<script id="tokensand-release-note" type="application/json">';
    const start = text.indexOf(marker), end = text.indexOf('</script>',start + marker.length);
    requireReplay(start >= 0 && start === text.lastIndexOf(marker) && end > start, 'Choose a release page with one embedded Tokens& note.');
    return JSON.parse(text.slice(start + marker.length,end));
  } finally { await file.close(); }
}
function selectCases(note, ids, all) {
  requireReplay(note?.kind === 'tokensand-release-note' && note.schemaVersion === 1 && ['all-recorded-cases','selected-cases'].includes(note.selection) && Array.isArray(note.cases)
    && note.cases.length > 0 && note.cases.length <= 20 && note.cases.every(c => shareableId(c?.id)) && new Set(note.cases.map(c => c.id)).size === note.cases.length
    && fullRevision.test(note.referenceRevision)
    && fullRevision.test(note.candidateRevision) && note.referenceRevision !== note.candidateRevision,
  'The note needs two distinct full Git revisions and a supported case list.');
  const requested = all ? note.cases.map(row => row.id) : ids;
  return requested.map(id => {
    const row = note.cases.find(row => row.id === id);
    requireReplay(row && ['still_passing','regressed','unknown'].includes(row.verdict), 'Choose a case listed in the note.');
    return selectClaim(note, row);
  });
}
function selectClaim(note, row) {
  if (row.verdict !== 'unknown') {
    const validCounts = score => score && Number.isInteger(score.total) && score.total >= 3 && score.total <= 10
      && Number.isInteger(score.passed) && score.passed >= 0 && score.passed <= score.total;
    requireReplay(validCounts(row.reference) && validCounts(row.candidate) && row.reference.passed === row.reference.total
      && row.reference.total === row.candidate.total && (row.verdict === 'still_passing') === (row.candidate.passed === row.candidate.total),
    'The selected claim disagrees with its reported trial counts.');
  }
  return { case:row.id, referenceRevision:note.referenceRevision, candidateRevision:note.candidateRevision, noteVerdict:row.verdict,
    ...(row.verdict === 'unknown' ? {} : {historicalTrialsPerRevision:row.reference.total}) };
}
function adapter() { return import(pathToFileURL(resolve('observe.workflow.mjs')).href).then(module => module.default); }
function single(w, id) {
  const cases = w.cases.filter(c => c.id === id);
  requireReplay(cases.length === 1 && w.maxCallsPerRun?.candidate === 0 && w.maxCallsPerRun?.baseline === 0,
    'Use one selected case and an offline workflow with zero provider budgets.');
  return cases[0];
}
async function serveOriginalScorer() {
  const request = await new Promise(resolve => process.once('message', resolve));
  try {
    const w = await adapter(), selected = single(w, request.id);
    const checks = w.checks.map(check => check.id);
    requireReplay(checks.length && new Set(checks).size === checks.length && checks.every(k => typeof k === 'string'), 'Invalid check definitions.');
    requireReplay(isDeepStrictEqual(request.input, selected.input), 'The selected input changed.');
    if (request.type === 'prepare') {
      process.send({ ok:true, checks, workflow:w.id, timeoutMs:w.timeoutMs });
    } else {
      requireReplay(request.type === 'score', 'Unknown request.');
      const scores = await w.evaluate({ input:structuredClone(selected.input), output:request.output, variant:'candidate' });
      const checked = [];
      for (const id of checks) {
        requireReplay(scores && Object.hasOwn(scores,id), 'The original check was unscored.');
        const score = typeof scores[id] === 'function' ? await scores[id]() : scores[id];
        requireReplay(typeof score === 'boolean', 'The original check was unscored.');
        checked.push([id,score]);
      }
      process.send({ok:true, checked});
    }
  } catch { process.send({ok:false}); }
}
function askOriginal(request) {
  return new Promise((yes, no) => {
    const child = fork(here,['--original-scorer'],{cwd:process.env.TOKENSAND_RECIPIENT_REFERENCE,
      execArgv:[],env:{...env,HOME:process.env.HOME,USERPROFILE:process.env.USERPROFILE},stdio:['ignore','ignore','ignore','ipc'],serialization:'advanced'});
    const timer = setTimeout(fail,10000);
    function finish() { clearTimeout(timer); child.kill('SIGKILL'); }
    function fail() { finish(); no(new Error('The original scorer could not verify this case.')); }
    child.once('error',fail); child.once('exit',fail);
    child.once('message', result => { finish(); result?.ok ? yes(result) : no(new Error('The original scorer could not verify this case.')); });
    child.send(request, error => { if (error) fail(); });
  });
}
async function publicAdapter() {
  const id = process.env.TOKENSAND_RECIPIENT_CASE;
  const w = await adapter(), selected = single(w,id);
  const spec = await askOriginal({type:'prepare',id,input:selected.input});
  requireReplay(w.id === spec.workflow && Number.isInteger(spec.timeoutMs) && spec.timeoutMs > 0 && w.timeoutMs === spec.timeoutMs,
    'Both revisions must select the same workflow and timeout.');
  return { cases:[selected], maxCallsPerRun:{candidate:0}, timeoutMs:spec.timeoutMs,
    checks:spec.checks.map(id => ({id})), candidate:w.candidate.bind(w),
    async evaluate({input,output}) {
      const { checked } = await askOriginal({type:'score',id,input,output});
      const scores = Object.fromEntries(checked);
      process.send({type:'scored',passed:checked.every(([,value]) => value)});
      return scores;
    },
  };
}
// Node owns each test's final timeout and teardown result. Forward only case statuses over IPC.
async function* reportTrials(events) {
  const id = process.env.TOKENSAND_RECIPIENT_CASE;
  for await (const {type,data} of events) {
    if (type === 'test:diagnostic' && /asynchronous activity after the test ended/.test(data.message)) process.send({type:'incomplete'});
    if (type !== 'test:pass' && type !== 'test:fail') continue;
    const index = [1,2,3].find(i => data.name === id + ' (trial ' + i + '/3)');
    if (!index || data.skip || data.todo || data.details?.error?.failureType === 'testTimeoutFailure') {
      process.send({type:'incomplete'});
    } else {
      process.send({type:'completed',index,passed:type === 'test:pass'});
    }
  }
}
const nativeReporter = 'data:text/javascript,' + encodeURIComponent('export default ' + reportTrials.toString());
function replay(cwd, earlier, id, home) {
  return new Promise((yes,no) => {
    const child = fork(checker,['--offline-workflow',here,'--case='+id], {cwd,execArgv:['--test-reporter=' + nativeReporter],
      env:{...env,HOME:home,USERPROFILE:home,TOKENSAND_RECIPIENT_REFERENCE:earlier,TOKENSAND_RECIPIENT_CASE:id},
      stdio:['ignore','ignore','ignore','ipc'], serialization:'advanced'});
    const trials = [], completed = new Map();
    let incomplete = false;
    const timer = setTimeout(() => { child.kill('SIGKILL'); no(new Inconclusive('The local replay timed out.')); }, 45000);
    child.on('message', msg => {
      if (msg?.type === 'scored' && typeof msg.passed === 'boolean') trials.push(msg.passed);
      if (msg?.type === 'completed') {
        if (completed.has(msg.index)) incomplete = true;
        completed.set(msg.index,msg.passed);
      }
      if (msg?.type === 'incomplete') incomplete = true;
    });
    child.once('error', () => { clearTimeout(timer); no(new Inconclusive('The public offline checker could not start.')); });
    child.once('close', status => {
      clearTimeout(timer);
      const passed = trials.filter(Boolean).length;
      if (incomplete || trials.length !== 3 || completed.size !== 3 || trials.some((v,i) => v !== completed.get(i+1)) || status !== (passed === 3 ? 0 : 1)) {
        no(new Inconclusive('The public checker could not complete three scored trials. Check the original case, timeout and offline dependencies.')); return;
      }
      yes({passed,total:3});
    });
  });
}
async function replaySelected(selected, repo, prefix) {
  const home = await mkdtemp(join(tmpdir(),'tokensand-recipient-'));
  try {
    const roots = [];
    for (const [which, revision] of [['reference',selected.referenceRevision],['candidate',selected.candidateRevision]]) {
      const dest = join(home,which);
      git(repo,'clone','--local','--no-checkout','--no-hardlinks','--quiet','--',repo,dest);
      git(dest,'checkout','--quiet','--detach',revision);
      requireReplay(git(dest,'rev-parse','HEAD') === revision, 'The checkout could not bind the selected revision.');
      roots.push(join(dest,prefix));
    }
    const reference = await replay(roots[0],roots[0],selected.case,home);
    const candidate = await replay(roots[1],roots[0],selected.case,home);
    const shorterPassingReplay = candidate.passed === candidate.total && candidate.total < selected.historicalTrialsPerRevision;
    const verdict = reference.passed !== reference.total || shorterPassingReplay ? 'unknown'
      : candidate.passed === candidate.total ? 'still_passing' : 'regressed';
    return {...selected, verdict,reference,candidate,
      ...(shorterPassingReplay ? {reason:'Three fresh passing trials cover fewer repetitions than the original check. Rerun the full recorded plan before clearing this case.'} : {}),
      agreement:verdict === 'unknown' || selected.noteVerdict === 'unknown' ? 'inconclusive' : selected.noteVerdict === verdict ? 'same_verdict' : 'different_verdict',
      provenance:'Fresh selected-case candidate trials on both Git revisions, evaluated by the reference scorer. Deployment and historical runs require separate evidence.'};
  } finally { await rm(home,{recursive:true,force:true}); }
}
function failureReason(error) {
  return error instanceof Inconclusive ? error.message : 'Unable to verify this local note, Git checkout or offline workflow.';
}
async function main() {
  const {values, positionals, tokens} = parseArgs({allowPositionals:true, tokens:true, options:{
    case:{type:'string',multiple:true}, 'all-cases':{type:'boolean'}, run:{type:'boolean'}, reference:{type:'string'}, help:{type:'boolean'}
  }});
  const flags = tokens.filter(token => token.kind === 'option' && token.name !== 'case').map(token => token.name);
  requireReplay(new Set(flags).size === flags.length, 'Supply each option once, except --case with distinct IDs.');
  if (values.help) { console.log(help); return 0; }
  const ids = values.case ?? [];
  const all = values['all-cases'] === true;
  requireReplay(positionals.length === 1 && (all ? ids.length === 0 : ids.length >= 1 && ids.length <= 20)
    && ids.every(shareableId) && new Set(ids).size === ids.length
    && (values.reference === undefined || /^[A-Za-z0-9][A-Za-z0-9._/-]{0,159}$/.test(values.reference)),
    'Choose --all-cases or up to 20 distinct --case IDs from one note. Add --run to recheck.');
  const note = await readNote(positionals[0]);
  const selected = selectCases(note, ids, all);
  const single = !all && selected.length === 1;
  const revisions = {referenceRevision:note.referenceRevision, candidateRevision:note.candidateRevision};
  const kind = 'tokensand-recipient-replay';
  if (!values.run) {
    safePrint({kind, status:'awaiting_replay', ...(single ? selected[0] : {...revisions,cases:selected}),
      next:'Add --run in the trusted service checkout to recheck both revisions with the reference scorer.'});
    return 2;
  }
  const cwd = process.cwd(), repo = git(cwd,'rev-parse','--show-toplevel'), prefix = git(cwd,'rev-parse','--show-prefix');
  requireReplay(git(cwd,'rev-parse','HEAD') === note.candidateRevision, 'Open the candidate revision from the shared note.');
  if (values.reference) requireReplay(git(cwd,'rev-parse','--verify','--end-of-options',values.reference + '^{commit}') === note.referenceRevision,
    'The independently selected reference differs from the shared note.');
  try { git(cwd,'merge-base','--is-ancestor',note.referenceRevision,note.candidateRevision); }
  catch { throw new Inconclusive('The reference must be a locally available ancestor of this candidate.'); }
  requireReplay(createHash('sha256').update(await readFile(checker)).digest('hex') === checkerHash, 'Install the matching public workflow checker before replaying.');

  const cases = [];
  for (const claim of selected) {
    try { cases.push(await replaySelected(claim,repo,prefix)); }
    catch (error) {
      if (single) throw error;
      cases.push({...claim,verdict:'unknown',reason:failureReason(error)});
    }
  }
  const verdict = cases.some(row => row.verdict === 'regressed') ? 'regressed'
    : cases.some(row => row.verdict === 'unknown') ? 'unknown' : 'still_passing';
  safePrint(single ? {kind,...cases[0]} : {kind,...revisions,verdict,cases});
  return verdict === 'regressed' ? 100 : verdict === 'unknown' ? 2 : 0;
}
let wrapped;
if (process.argv[1] && resolve(process.argv[1]) === here) {
  if (process.argv[2] === '--original-scorer' && process.send) await serveOriginalScorer();
  else try { process.exitCode = await main(); }
  catch (error) {
    safePrint({kind:'tokensand-recipient-replay',verdict:'unknown',reason:failureReason(error)}); process.exitCode = 2;
  }
} else if (process.send && process.env.TOKENSAND_RECIPIENT_REFERENCE) {
  wrapped = await publicAdapter();
}
export default wrapped;
