// The author runs trusted project code locally. PR verification only reads committed Git objects.
import { spawnSync } from "node:child_process";
import { appendFileSync, existsSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, renameSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const receiptPath = ".tokensand/starter-check.json";
const adapter = "observe.workflow.mjs";
const starter = fileURLToPath(new URL("./first-check-v3.mjs", import.meta.url));
const schema = "tokensand-starter-cases-v1";
const sha = /^[0-9a-f]{40}$/;
const recipe = "Run the public Tokens& checker with --pr-receipt on the committed code. Then commit only " + receiptPath + ".";
const messages = {
  missing: recipe,
  uncommitted: "Commit your app and its offline observe.workflow.mjs before recording a PR result. Run --offline-workflow ./observe.workflow.mjs to check it before committing.",
  setup: "Create and commit a trusted offline observe.workflow.mjs in the repository root. " + recipe,
  stale: "The receipt must identify the PR head’s only parent and be the only change in the head commit. " + recipe,
  invalid: "The evidence could not be verified. " + recipe,
  failed: "Run the public checker with --offline-workflow ./observe.workflow.mjs to see the failing cases locally.",
  passed: "Review the tested revision and its case coverage before merging.",
};
const codes = { passed: 0, failed: 100, invalid: 1, missing: 2, uncommitted: 2, setup: 2, stale: 3 };

function requireState(condition, status = "invalid") {
  if (!condition) throw new Error(status);
}
function command(binary, args, options = {}) {
  const result = spawnSync(binary, args, { encoding: "utf8", maxBuffer: 256 * 1024, ...options });
  requireState(result.status === 0);
  return (result.stdout ?? "").trim();
}
function git(...args) { return command("git", args); }
function modeAt(revision, path) {
  return git("ls-tree", revision, "--", path).split(" ")[0];
}
function regularFile(revision, path) {
  return ["100644", "100755"].includes(modeAt(revision, path));
}
function validCounts(value) {
  return value && [value.passedCases, value.failedCases].every(n => Number.isSafeInteger(n) && n >= 0)
    && Number.isSafeInteger(value.passedCases + value.failedCases) && value.passedCases + value.failedCases > 0;
}

// Node invokes this reporter only in the local scoring process. Keep test names and callback output out of the receipt.
export default async function* countCases(events) {
  let passedCases = 0, failedCases = 0, planned = null, valid = true;
  for await (const { type, data } of events) {
    if (type === "test:plan" && data.nesting === 0) {
      valid &&= planned === null;
      planned = data.count;
    }
    if (type !== "test:pass" && type !== "test:fail") continue;
    valid &&= data.file === starter && data.nesting === 0 && !data.skip && !data.todo;
    if (type === "test:pass") passedCases++;
    else failedCases++;
  }
  if (valid && planned === passedCases + failedCases && validCounts({ passedCases, failedCases })) {
    writeFileSync(process.env.TOKENSAND_STARTER_COUNTS, JSON.stringify({ passedCases, failedCases }), { flag: "wx", mode: 0o600 });
  }
}

function record(head) {
  requireState(regularFile(head, adapter), "setup");
  function assertClean() {
    requireState(git("rev-parse", "HEAD") === head && git("status", "--porcelain", "--untracked-files=no", "--", ".", ":(exclude,literal)" + receiptPath) === "", "stale");
  }
  assertClean();
  const root = realpathSync("."), temp = mkdtempSync(join(realpathSync(tmpdir()), "tokensand-starter-"));
  try {
    const clone = join(temp, "source"), hooks = join(temp, "hooks"), counts = join(temp, "counts.json");
    mkdirSync(hooks);
    command("git", ["-c", "core.hooksPath=" + hooks, "clone", "--quiet", "--shared", "--no-checkout", "--", root, clone]);
    command("git", ["-c", "core.hooksPath=" + hooks, "-C", clone, "checkout", "--quiet", "--detach", head]);
    if (existsSync(join(root, "node_modules"))) symlinkSync(realpathSync(join(root, "node_modules")), join(clone, "node_modules"), "junction");
    const env = Object.fromEntries(["PATH", "SystemRoot", "LANG", "TMPDIR", "TEMP", "TMP"].filter(key => process.env[key]).map(key => [key, process.env[key]]));
    const result = spawnSync(process.execPath, ["--test-reporter=" + import.meta.url, starter, "--offline-workflow", "./" + adapter], {
      cwd: clone, env: { ...env, TOKENSAND_STARTER_COUNTS: counts }, timeout: 300_000, stdio: "ignore",
    });
    requireState(existsSync(counts) && !result.error && !result.signal);
    const totals = JSON.parse(readFileSync(counts, "utf8"));
    requireState(validCounts(totals) && result.status === (totals.failedCases ? 1 : 0));
    assertClean();
    const dir = dirname(receiptPath);
    if (!existsSync(dir)) mkdirSync(dir);
    requireState(lstatSync(dir).isDirectory());
    const output = join(dir, ".starter-" + randomUUID());
    try {
      writeFileSync(output, JSON.stringify({ schema, revision: head, passedCases: totals.passedCases, failedCases: totals.failedCases }) + "\n", { mode: 0o600, flag: "wx" });
      renameSync(output, receiptPath);
    } finally { rmSync(output, { force: true }); }
    return totals;
  } finally { rmSync(temp, { recursive: true, force: true }); }
}

function verify(head) {
  const expected = process.env.EXPECTED_PR_HEAD;
  if (expected !== undefined) requireState(sha.test(expected) && head === expected, "stale");
  const mode = modeAt(head, receiptPath);
  requireState(mode, "missing");
  requireState(regularFile(head, receiptPath) && Number(git("cat-file", "-s", head + ":" + receiptPath)) <= 512);
  const receipt = JSON.parse(git("show", head + ":" + receiptPath));
  requireState(receipt?.schema === schema && Object.keys(receipt).length === 4 && typeof receipt.revision === "string" && sha.test(receipt.revision) && validCounts(receipt));
  requireState(git("rev-list", "--parents", "-n", "1", head) === head + " " + receipt.revision, "stale");
  requireState(git("diff-tree", "--no-commit-id", "--no-renames", "--name-only", "-r", head) === receiptPath, "stale");
  requireState(regularFile(receipt.revision, adapter), "setup");
  return receipt;
}

export function starterReview(action) {
  let status = "invalid", head, revision, totals;
  try {
    process.chdir(git("rev-parse", "--show-toplevel"));
    const revisionRead = spawnSync("git", ["rev-parse", "--verify", "HEAD^{commit}"], { encoding: "utf8" });
    requireState(revisionRead.status === 0, "uncommitted");
    head = revisionRead.stdout.trim();
    requireState(sha.test(head));
    if (action === "record") { totals = record(head); revision = head; }
    else { requireState(action === "verify"); totals = verify(head); revision = totals.revision; }
    status = totals.failedCases ? "failed" : "passed";
  } catch (e) {
    status = Object.hasOwn(codes, e.message) ? e.message : "invalid";
  }
  const lines = ["## Tokens& starter cases", "", "Status: **" + status + "**"];
  if (head && sha.test(head)) lines.push("Checkout: `" + head + "`");
  if (totals) lines.push("Evaluated revision: `" + revision + "`", "Author-reported candidate cases: " + totals.passedCases + " passed, " + totals.failedCases + " failed.");
  if (totals && action === "record") lines.push("Receipt: `" + receiptPath + "`");
  lines.push("Next: " + messages[status], "");
  const report = lines.join("\n");
  console.log(report);
  if (action === "verify" && process.env.GITHUB_STEP_SUMMARY) appendFileSync(process.env.GITHUB_STEP_SUMMARY, report + "\n");
  return codes[status];
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  process.exitCode = starterReview(process.argv[2]);
}
